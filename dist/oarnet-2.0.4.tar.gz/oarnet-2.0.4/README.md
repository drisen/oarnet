# oarnet Package

**oarnet.py** application to real-time poll the OARnet statistics from https://gateway.oar.net/stats/api to update
a historical record of traffic at each of the selected interfaces. 
email significant dropped traffic via email.

