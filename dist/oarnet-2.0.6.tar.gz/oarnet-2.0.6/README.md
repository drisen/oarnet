# oarnet Package

**oarnet.py** Application to real-time poll the OARnet statistics from
https://gateway.oar.net/stats/api to update
a historical record of traffic at each of the selected interfaces. 
Provide alerts of significant dropped traffic conditions via email.

